using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Testing : MonoBehaviour
{
    [SerializeField] private Unit unit;
    private void Start()
    {
        
    }
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.T))
        {
            ScreenShake.Instance.Shake();
        }
    }
}
